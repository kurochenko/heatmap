
var fs = require('fs')
var unzip = require('unzip2')
var AWS = require('aws-sdk');
var util = require('util');
var async = require('async');

var s3 = new AWS.S3();

function saveS3(entry) {
	console.log('Saving')
	console.log(entry)
}

exports.handler = function(event, context) {

	console.log("Reading options from event:\n", util.inspect(event, {depth: 5}));


	var srcBucket = event.Records[0].s3.bucket.name;
	var srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));
	// fs.createReadStream('/Users/kurochenko/tmp/hmap/0.zip').pipe(unzip.Extract({
	// 	path: '/Users/kurochenko/tmp/hmap/out/'
	// }));
	console.log(srcBucket)
	console.log(srcKey)

	async.waterfall([
		function download(next) {
			next(s3.getObject({
				Bucket: srcBucket,
				Key: srcKey
			}).createReadStream());
		},
		function unzipFile(response, next) {
			console.log(response)
			response.pipe(unzip.Parse())
				.on('entry', saveS3)
				.on('finish', next)
			   // .on('finish', next);

			// response.pipe(unzip.Extract({
			// 	path: '/Users/kurochenko/tmp/hmap/out/'
			// }));
		},
		function upload(xyz, next) {
			console.log(xyz)
			next()
		}
		// ,
		// function upload() {
		// 	s3.putObject({
		// 		Bucket: srcBucket,
		// 		Key: dstKey,
		// 		Body: data,
		// 		ContentType: contentType
		// 	},
		// 	next);
		// }
	], function (err) {
			if (err) {
				console.error(err);
			} else {
				console.log('ok');
			}

			context.done();
		}
	)
}

